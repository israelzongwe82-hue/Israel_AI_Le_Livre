const chapters = [
{
 title:"Partie 1 — L’identité du créateur", text:`
 <h2>🪪 KIBWE ZONGWE Israël</h2>
 <p>Le créateur d’Israël_AI s’appelle <b>KIBWE ZONGWE Israël</b>. Il est né à Kasenga, le mercredi 27 mai 2009, et étudie à l’Institut CISANIKO à Kasenga.</p>
 <p>Son objectif est d’apprendre l’informatique, de comprendre la programmation, de créer ses propres applications et jeux et de devenir un informaticien-programmeur capable de travailler sur de grands projets.</p>
 <p>Le nom <b>Israël_AI</b> vient de son propre prénom. Il a choisi ce nom parce qu’il voulait que le projet porte son identité de créateur.</p>`,
 quiz:[
 ["Qui est le créateur d’Israël_AI ?",["Sijafurahi Zongwe","KIBWE ZONGWE Israël","Une entreprise","Un logiciel"],1],
 ["D’où vient le nom Israël_AI ?",["Du nom d’une entreprise","Du prénom Israël du créateur","De GitHub","De Python"],1],
 ["Quel est l’un des objectifs du créateur ?",["Arrêter d’apprendre","Devenir informaticien-programmeur","Ne plus utiliser d’ordinateur","Créer seulement des images"],1]
 ]
},
{
 title:"Partie 2 — Mes premières découvertes", text:`
 <h2>👦 Avant la programmation</h2>
 <p>Très jeune, Israël s’intéressait déjà à la technologie. Entre environ 5 et 7 ans, il aimait manipuler différents téléviseurs avec leurs télécommandes et apprendre leur fonctionnement.</p>
 <p>Vers 7 ans, son intérêt pour l’informatique est devenu plus sérieux. Il observait et cherchait à comprendre les appareils technologiques autour de lui.</p>
 <p>Cette curiosité a constitué une première étape de son parcours.</p>`,
 quiz:[
 ["Qu’est-ce qu’Israël aimait manipuler lorsqu’il était petit ?",["Des téléviseurs et leurs télécommandes","Des serveurs","Des drones","Des consoles professionnelles"],0],
 ["Vers quel âge son intérêt pour l’informatique est-il devenu plus sérieux ?",["3 ans","7 ans","15 ans","20 ans"],1]
 ]
},
{
 title:"Partie 3 — L’idée d’un jeu à 13 ans", text:`
 <h2>🎮 Une première idée de programmation</h2>
 <p>À 13 ans, Israël a commencé à penser à programmer un jeu. Ce n’était pas encore une étude organisée de la programmation : c’était surtout une idée et une envie de créer.</p>
 <p>À cette époque, il n’avait pas encore de téléphone ou d’ordinateur lui permettant de programmer comme il le souhaitait. L’idée est pourtant restée dans son esprit.</p>
 <p>Cette expérience montre qu’un projet peut commencer par une simple idée, même avant d’avoir les outils nécessaires.</p>`,
 quiz:[
 ["Que voulait-il commencer à programmer vers 13 ans ?",["Un jeu","Un réseau social","Une télévision","Un système bancaire"],0],
 ["Pourquoi ne pouvait-il pas encore programmer comme il le souhaitait ?",["Il n’aimait pas programmer","Il n’avait pas encore le téléphone ou l’ordinateur nécessaire","Il avait déjà terminé son projet","Il n’avait pas de clavier Bluetooth"],1]
 ]
},
{
 title:"Partie 4 — Les premières IA", text:`
 <h2>🤖 Des essais aux systèmes plus avancés</h2>
 <p>Plus tard, Israël a commencé à expérimenter sur ordinateur. Il a d’abord créé une IA simple qui répondait seulement aux questions et réponses prévues dans le code.</p>
 <p>Il a ensuite créé une autre IA liée à <b>Ollama</b>. Elle pouvait produire des réponses plus générales, mais les essais hors ligne pouvaient parfois contenir des erreurs.</p>
 <p>Ces expériences lui ont permis de comprendre progressivement la différence entre un programme à réponses prévues et une application connectée à un modèle d’IA.</p>`,
 quiz:[
 ["Comment fonctionnait la première IA expérimentée ?",["Elle répondait selon les réponses prévues dans le code","Elle lisait dans les pensées","Elle utilisait uniquement la télévision","Elle n’avait aucun code"],0],
 ["À quel outil une autre IA a-t-elle été liée ?",["Ollama","Chrome uniquement","Paint","Excel"],0],
 ["Que pouvait-il arriver avec les réponses hors ligne ?",["Elles étaient toujours parfaites","Il pouvait y avoir des erreurs","Il n’y avait jamais de réponse","Le téléphone devenait une imprimante"],1]
 ]
},
{
 title:"Partie 5 — La création d’Israël_AI", text:`
 <h2>📱 De l’ordinateur au téléphone</h2>
 <p>À 17 ans, Israël a réellement commencé à programmer une APK appelée <b>Israël_AI</b>.</p>
 <p>Une étape a consisté à créer une IA qui fonctionnait sur son téléphone. Au début, pour l’utiliser depuis un autre téléphone, il fallait passer par la même connexion Wi‑Fi.</p>
 <p>Le projet a ensuite évolué jusqu’à une version publiée sous forme d’APK mobile pouvant être installée sur d’autres téléphones.</p>
 <p>Le but personnel était simple : apprendre la programmation, avoir sa propre IA et approfondir ses connaissances.</p>`,
 quiz:[
 ["À quel âge Israël a-t-il créé l’APK Israël_AI ?",["10 ans","13 ans","17 ans","25 ans"],2],
 ["Au début, comment un autre téléphone pouvait-il accéder à l’IA sur le téléphone ?",["Avec la même connexion Wi‑Fi","Avec une télévision","Sans aucun réseau dans tous les cas","Avec une imprimante"],0],
 ["Pourquoi Israël a-t-il créé Israël_AI ?",["Pour apprendre la programmation et avoir son IA personnelle","Pour remplacer toutes les écoles","Pour arrêter d’étudier","Pour fabriquer un téléviseur"],0]
 ]
},
{
 title:"Partie 6 — Technologies, langages et outils", text:`
 <h2>💻 Ce qui a servi au parcours</h2>
 <p><b>Python</b> a servi à programmer une grande partie du fonctionnement. <b>Flask</b> a servi pour le serveur web de l’application.</p>
 <p><b>HTML, CSS et JavaScript</b> servent à construire les pages et les interactions web. Dans le livre actuel, JavaScript sert notamment aux chapitres et aux quiz.</p>
 <p><b>Pydroid 3</b> a permis de travailler avec Python sur Android. <b>GitHub</b> a servi à stocker et gérer les fichiers du projet. <b>Render</b> a servi à héberger la version en ligne.</p>
 <p><b>Chrome</b> a servi à tester l’IA depuis le navigateur. <b>Capacitor</b> sert à transformer le projet web du livre en application Android.</p>
 <p>Des commandes comme <b>cd</b>, <b>pip</b>, <b>npm</b>, <b>git</b> et les commandes de compilation font partie de l’écosystème de développement. Une commande est une instruction donnée à un outil : elle n’est pas un langage de programmation.</p>`,
 quiz:[
 ["Quel langage a servi à programmer une grande partie du fonctionnement ?",["Python","CSS","PNG","JSON"],0],
 ["Quel framework serveur a été utilisé ?",["Flask","Chrome","GitHub","Capacitor"],0],
 ["Quel outil a permis de travailler avec Python sur Android ?",["Pydroid 3","Render","CSS","Git"],0],
 ["Quel outil a servi à héberger la version en ligne ?",["Render","Pydroid 3","HTML","Capacitor"],0],
 ["Quelle affirmation est correcte ?",["JavaScript est une commande","cd et pip sont des langages de programmation","Une commande donne une instruction à un outil","PNG est un langage"],2]
 ]
},
{
 title:"Partie 7 — Les difficultés et la persévérance", text:`
 <h2>🛠️ Les erreurs font partie de l’apprentissage</h2>
 <p>La création n’a pas été sans difficultés. Israël a rencontré des erreurs dans le code et des problèmes pendant les étapes de publication.</p>
 <p>GitHub et Render ont aussi demandé des essais et des corrections. Certaines étapes n’ont pas fonctionné du premier coup. Il a fallu rechercher les erreurs, modifier le projet, tester encore et continuer.</p>
 <p>Il n’a pas abandonné parce qu’il voulait réaliser son souhait : créer une APK et montrer aux autres que lui aussi pouvait y arriver.</p>`,
 quiz:[
 ["Quelle difficulté a été rencontrée ?",["Des erreurs de code","Aucune difficulté","Uniquement des problèmes de télévision","Aucun test"],0],
 ["Quels services ont demandé des essais et des corrections ?",["GitHub et Render","Une imprimante et une radio","Excel et Paint","Une télévision et une caméra"],0],
 ["Pourquoi a-t-il continué ?",["Pour réaliser son projet et montrer qu’il en était capable","Parce qu’il n’y avait aucun problème","Pour arrêter la programmation","Pour supprimer l’application"],0]
 ]
},
{
 title:"Partie 8 — Publication, APK et hors connexion", text:`
 <h2>📦 De l’application au partage</h2>
 <p>Après les essais, Israël a obtenu une version APK mobile et l’a installée sur son téléphone. Il a également pu la partager avec d’autres personnes.</p>
 <p>Le présent livre est conçu pour être consulté hors connexion après son installation. Les textes, chapitres, quiz et progression sont intégrés localement dans l’application.</p>
 <p>Une connexion Internet peut être nécessaire pour télécharger l’APK initialement ou pour utiliser certains services en ligne d’un autre projet, mais le contenu de ce livre n’a pas besoin de forfait une fois installé.</p>`,
 quiz:[
 ["Le livre peut-il être lu hors connexion après installation ?",["Oui","Non","Seulement la nuit","Seulement avec Wi‑Fi"],0],
 ["Où sont conservés les chapitres du livre ?",["Dans l’application","Uniquement sur Internet","Dans une télévision","Dans une imprimante"],0],
 ["À quoi sert l’APK ?",["À installer l’application Android","À écrire seulement des lettres","À remplacer GitHub","À créer une connexion Wi‑Fi"],0]
 ]
},
{
 title:"Partie 9 — Motivation et message aux jeunes", text:`
 <h2>🌟 Continuer malgré les erreurs</h2>
 <p>Israël adresse ce message aux jeunes :</p>
 <blockquote>« Vous êtes intelligents, car toute personne est intelligente. Vous pouvez aussi créer vos propres applications, que ce soit pour Windows, Android ou d’autres plateformes. Je vous encourage à ne pas abandonner, même lorsqu’il y a des erreurs ou des problèmes. On commence avec de petites choses et, avec le temps, on gagne des connaissances. Ne vous découragez pas, même lorsque vous êtes fatigués. Essayez de trouver la joie qui se trouve dans la programmation et avancez même en cas d’erreur. »</blockquote>
 <p class="verse">📖 <b>Philippiens 4:13 :</b> « Je peux tout par celui qui me fortifie. »</p>
 <p>Le parcours présenté dans ce livre n’est pas celui d’une réussite sans erreurs. C’est celui d’un apprentissage progressif : essayer, se tromper, comprendre, corriger et continuer.</p>`,
 quiz:[
 ["Quel est le message principal d’Israël aux jeunes ?",["Abandonner lorsqu’il y a une erreur","Commencer petit, apprendre et persévérer","Ne jamais essayer de programmer","Attendre d’être expert avant de commencer"],1],
 ["Que peut-on faire après une erreur de programmation ?",["Chercher à comprendre et corriger","Tout abandonner immédiatement","Cacher l’erreur sans apprendre","Supprimer tous les fichiers"],0],
 ["Quel verset est utilisé dans le livre ?",["Jean 3:16","Philippiens 4:13","Psaume 23:1","Matthieu 5:9"],1]
 ]
}
];

let currentChapter=0, quizIndex=0, score=0;

function show(id){
 document.querySelectorAll('.screen').forEach(x=>x.classList.remove('active'));
 document.getElementById(id).classList.add('active');
 if(id==="chapters") renderChapters();
 if(id==="progress") renderProgress();
 window.scrollTo(0,0);
}
function renderChapters(){
 document.getElementById('chapterList').innerHTML=chapters.map((c,i)=>`<div class="card"><h3>${c.title}</h3><button onclick="openChapter(${i})">📖 Ouvrir</button></div>`).join('');
}
function openChapter(i){
 currentChapter=i;
 document.getElementById('chapterContent').innerHTML=`<div class="card">${chapters[i].text}</div>`;
 show('reader');
}
function startQuiz(i){
 currentChapter=i; quizIndex=0; score=0; show('quiz'); renderQuestion();
}
function renderQuestion(){
 const q=chapters[currentChapter].quiz[quizIndex];
 document.getElementById('quizContent').innerHTML=`<div class="card"><div class="small">Question ${quizIndex+1}/${chapters[currentChapter].quiz.length}</div><h2>${q[0]}</h2>${q[1].map((o,i)=>`<button class="option" onclick="answer(${i})">${String.fromCharCode(65+i)}. ${o}</button>`).join('')}</div>`;
}
function answer(choice){
 const q=chapters[currentChapter].quiz[quizIndex];
 const buttons=document.querySelectorAll('.option');
 buttons.forEach((b,i)=>{b.disabled=true;if(i===q[2])b.classList.add('correct');if(i===choice&&i!==q[2])b.classList.add('wrong')});
 if(choice===q[2])score++;
 setTimeout(()=>{quizIndex++;if(quizIndex<chapters[currentChapter].quiz.length)renderQuestion();else finishQuiz();},700);
}
function finishQuiz(){
 const total=chapters[currentChapter].quiz.length, pct=Math.round(score/total*100);
 localStorage.setItem("quiz_"+currentChapter, JSON.stringify({score,total,pct}));
 document.getElementById('quizContent').innerHTML=`<div class="card"><div class="score">🏆 ${score}/${total}</div><p class="score">${pct}%</p><p style="text-align:center">Quiz terminé !</p><button onclick="openChapter(${currentChapter})">📖 Revoir le chapitre</button><button onclick="show('chapters')">📚 Choisir un autre chapitre</button></div>`;
}
function renderProgress(){
 const done=chapters.map((c,i)=>{const r=JSON.parse(localStorage.getItem("quiz_"+i)||"null");return `<p>${c.title} : ${r?`✅ ${r.score}/${r.total} (${r.pct}%)`:'⬜ Pas encore terminé'}</p>`;}).join('');
 document.getElementById('progressText').innerHTML=`<div class="card">${done}</div>`;
}

renderChapters();
