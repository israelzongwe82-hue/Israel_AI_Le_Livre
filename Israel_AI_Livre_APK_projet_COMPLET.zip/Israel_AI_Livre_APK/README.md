# Israël_AI — Le Livre

Livre éducatif interactif sur la création d’Israël_AI, avec chapitres, quiz, progression et fonctionnement hors connexion après installation.

## Contenu
- Identité publique du créateur KIBWE ZONGWE Israël
- Premières découvertes technologiques pendant l’enfance
- Idée de programmer un jeu vers 13 ans
- Premières expériences d’IA
- Création d’Israël_AI à 17 ans
- Python, Flask, HTML, CSS, JavaScript, Pydroid 3, GitHub, Render, Chrome et Capacitor
- Difficultés, erreurs et persévérance
- APK et fonctionnement hors connexion
- Message de motivation et verset biblique
- Quiz avec score et progression locale

## Confidentialité
La version publique du livre n’intègre pas le numéro de téléphone ni les noms complets des membres de la famille du créateur.

## Construction APK
Le projet utilise Capacitor. Le workflow GitHub Actions peut installer les dépendances, ajouter Android, synchroniser le projet et construire l’APK.
