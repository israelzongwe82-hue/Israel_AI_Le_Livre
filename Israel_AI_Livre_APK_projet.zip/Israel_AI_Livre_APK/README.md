# Israël_AI — Le Livre

Livre éducatif interactif conçu pour fonctionner hors connexion après installation.

Contenu actuel :
- Histoire et identité d'Israël_AI
- Comprendre Israël_AI
- Création du projet depuis Android/Pydroid 3
- Technologies et outils
- Sécurité des clés API
- APK et mode hors connexion
- Quiz interactifs avec score et progression

Pour créer l'APK avec Capacitor :
1. Installer Node.js et npm.
2. Dans ce dossier : `npm install`
3. `npx cap add android`
4. `npx cap sync android`
5. Ouvrir le projet Android avec Android Studio ou construire avec Gradle.
