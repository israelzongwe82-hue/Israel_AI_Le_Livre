const chapters=[
{title:"Partie 1 — L’histoire et l’identité d’Israël_AI",text:`
<h2>👤 L’histoire et l’identité</h2>
<p>Israël_AI est un projet personnel créé par <b>Israël Zongwe</b>. Le projet est né de la volonté de comprendre comment créer une vraie application d’intelligence artificielle.</p>
<p><b>Date de création :</b> 19 septembre 2026.</p>
<p><b>Lieu :</b> Kasenga, République démocratique du Congo.</p>`,
quiz:[
["Qui est le créateur du projet Israël_AI ?",["Sijafurahi Zongwe","Israël Zongwe","Daniel Mwamba","Une entreprise"],1],
["Quel est le nom du projet ?",["Sijafurahi","Israël_AI","Pydroid 3","GitHub"],1],
["Où le projet a-t-il été créé ?",["Kasenga, RDC","Paris","Londres","Une entreprise"],0]
]},
{title:"Partie 2 — Comprendre Israël_AI",text:`
<h2>🤖 Comprendre Israël_AI</h2>
<p>Une application d’IA combine plusieurs éléments. Dans notre projet, Python a servi à programmer le fonctionnement, tandis que HTML, CSS et JavaScript ont servi à construire l’interface. Flask a servi de cadre serveur et une API permet la communication avec un service d’IA.</p>
<p>Des outils comme GitHub et Render ont aussi participé aux étapes de gestion et de mise en ligne du projet.</p>`,
quiz:[
["Quel langage avons-nous utilisé pour programmer une grande partie du projet ?",["JavaScript","CSS","Python","HTML"],2],
["Quelle technologie avons-nous utilisée pour le serveur ?",["Flask","CSS","GitHub","Capacitor"],0],
["Quel élément permet la communication avec un service d’IA ?",["Notepad","API","HTML","CMD"],1]
]},
{title:"Partie 3 — Comment nous avons créé Israël_AI",text:`
<h2>🛠️ De l’idée à l’application</h2>
<p>Le projet a commencé par une idée, puis nous avons programmé et testé progressivement l’application.</p>
<p><b>Important :</b> notre expérience de création s’est faite principalement avec un appareil Android, notamment avec <b>Pydroid 3</b>. Le livre ne prétend donc pas que l’application a été créée principalement sur ordinateur.</p>
<p>Nous avons ensuite travaillé avec les outils réellement utilisés pour le projet, puis mis l’application en ligne et obtenu une version APK.</p>`,
quiz:[
["Avec quel appareil avons-nous principalement travaillé pour créer le projet ?",["Un appareil Android","Une console","Une télévision","Une imprimante"],0],
["Quelle application Android avons-nous utilisée pour travailler avec Python ?",["Pydroid 3","Render","GitHub","Capacitor"],0],
["Quel est le principe correct de notre parcours ?",["Idée → code → tests → mise en ligne → APK","APK → idée → batterie","GitHub → téléphone cassé → code","Entreprise → serveur → idée"],0]
]},
{title:"Partie 4 — Les technologies et outils",text:`
<h2>💻 Technologies et outils</h2>
<p><b>Python</b> : programmation du fonctionnement.</p>
<p><b>Flask</b> : serveur web de l’application.</p>
<p><b>HTML/CSS/JavaScript</b> : interface et interactions.</p>
<p><b>Pydroid 3</b> : environnement Android utilisé pour travailler avec Python.</p>
<p><b>GitHub</b> : gestion et stockage du projet.</p>
<p><b>Render</b> : hébergement en ligne.</p>
<p><b>Capacitor</b> : transformation d’un projet web en application Android.</p>`,
quiz:[
["Quel outil avons-nous utilisé sur Android pour travailler avec Python ?",["Pydroid 3","Render","CSS","Capacitor"],0],
["Quel langage sert principalement à programmer le fonctionnement ?",["Python","HTML","CSS","PNG"],0],
["Quel outil est associé à l’hébergement en ligne du projet ?",["Render","Notepad","Python","HTML"],0],
["Quel outil peut servir à transformer une application web en APK Android ?",["Capacitor","CSS","CMD","JSON"],0]
]},
{title:"Partie 5 — Sécurité et clé API",text:`
<h2>🔐 Sécurité</h2>
<p>Une clé API est une information secrète. Elle ne doit pas être publiée dans une application, un dépôt public ou un message.</p>
<p>Dans un vrai projet, on utilise des variables d’environnement ou un serveur sécurisé pour protéger les secrets.</p>`,
quiz:[
["Que doit-on faire avec une clé API secrète ?",["La publier","La partager avec tout le monde","La protéger","La mettre dans le titre"],2],
["Où vaut-il mieux garder un secret ?",["Dans un système sécurisé","Dans un message public","Dans une capture d’écran","Dans le nom de l’application"],0]
]},
{title:"Partie 6 — L’APK et le mode hors connexion",text:`
<h2>📱 L’APK</h2>
<p>Le livre lui-même est conçu pour être utilisé hors connexion. Les chapitres et les quiz sont intégrés dans l’application afin que l’utilisateur n’ait pas besoin de forfait pour les consulter après installation.</p>
<p>Une connexion peut toutefois être nécessaire pour télécharger l’APK initialement.</p>`,
quiz:[
["Le livre peut-il être utilisé sans forfait après installation ?",["Oui","Non","Seulement la nuit","Seulement avec Wi‑Fi"],0],
["Où sont placés les chapitres du livre hors ligne ?",["Dans l’application","Uniquement sur Internet","Dans une chaîne TV","Dans une imprimante"],0]
]}
];

let currentChapter=0, quizIndex=0, score=0;

function show(id){
 document.querySelectorAll('.screen').forEach(x=>x.classList.remove('active'));
 document.getElementById(id).classList.add('active');
 if(id==="chapters") renderChapters();
 if(id==="progress") renderProgress();
 window.scrollTo(0,0);
}
function renderChapters(){
 chapterList.innerHTML=chapters.map((c,i)=>`<div class="card"><h3>${c.title}</h3><button onclick="openChapter(${i})">📖 Ouvrir</button></div>`).join('');
}
function openChapter(i){
 currentChapter=i; chapterContent.innerHTML=`<div class="card">${chapters[i].text}</div>`; show('reader');
}
function startQuiz(i){
 currentChapter=i; quizIndex=0; score=0; show('quiz'); renderQuestion();
}
function renderQuestion(){
 const q=chapters[currentChapter].quiz[quizIndex];
 quizContent.innerHTML=`<div class="card"><div class="small">Question ${quizIndex+1}/${chapters[currentChapter].quiz.length}</div><h2>${q[0]}</h2>${q[1].map((o,i)=>`<button class="option" onclick="answer(${i})">${String.fromCharCode(65+i)}. ${o}</button>`).join('')}</div>`;
}
function answer(choice){
 const q=chapters[currentChapter].quiz[quizIndex];
 const buttons=document.querySelectorAll('.option');
 buttons.forEach((b,i)=>{b.disabled=true;if(i===q[2])b.classList.add('correct');if(i===choice&&i!==q[2])b.classList.add('wrong')});
 if(choice===q[2])score++;
 setTimeout(()=>{
  quizIndex++;
  if(quizIndex<q.length) renderQuestion(); else finishQuiz();
 },700);
}
function finishQuiz(){
 const total=chapters[currentChapter].quiz.length, pct=Math.round(score/total*100);
 localStorage.setItem("quiz_"+currentChapter, JSON.stringify({score,total,pct}));
 quizContent.innerHTML=`<div class="card"><div class="score">🏆 ${score}/${total}</div><p class="score">${pct}%</p><p style="text-align:center">Quiz terminé !</p><button onclick="openChapter(${currentChapter})">📖 Revoir le chapitre</button><button onclick="show('chapters')">📚 Choisir un autre chapitre</button></div>`;
}
function renderProgress(){
 const done=chapters.map((c,i)=>{
  const r=JSON.parse(localStorage.getItem("quiz_"+i)||"null");
  return `<p>${c.title} : ${r?`✅ ${r.score}/${r.total} (${r.pct}%)`:"⬜ Pas encore terminé"}</p>`;
 }).join('');
 progressText.innerHTML=`<div class="card">${done}</div>`;
}
renderChapters();
